import Collectable from "./Collectible.js";
class Heart extends Collectable{
    #value ;

    constructor(x, y, width, height, texturepath,value,spriteSheetOffsetX) {
        if(spriteSheetOffsetX === undefined || spriteSheetOffsetX === null || spriteSheetOffsetX === 0){
            spriteSheetOffsetX = 7;
        }
        if(value === undefined || value === null || value === 0){
            value = 2;
        }
        super(x, y, width, height, texturepath,spriteSheetOffsetX);
        this.song = new Audio("assets/sounds/collectible/heart_gain.wav");
        this.#value = value;
    }
    get value() {
        return this.#value;
    }

    set value(value) {
        this.#value = value;
    }

    collect(player) {
        this.debug ? console.log("heart gain") : null;
        player.addHeartCollected(this.value);
    }
}

export default Heart;