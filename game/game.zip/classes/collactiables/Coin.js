import Collectable from "./Collectible.js";

class Coin extends Collectable{
    #value = 14;

    constructor(x, y, width, height, texturepath,value,spriteSheetOffsetX) {
        if(spriteSheetOffsetX === undefined){
            spriteSheetOffsetX = 0;
        }
        super(x, y, width, height, texturepath, spriteSheetOffsetX);
        this.song = new Audio("assets/sounds/collectible/coin.wav");
        this.song.volume = 0.3;
        this.#value = value;
    }
    get value() {
        return this.#value;
    }

    set value(value) {
        this.#value = value;
    }

    collect(player) {
        this.debug ? console.log("coin collected") : null;
        player.score += this.#value;
        player.addCoinCollected();
    }
}
export default Coin;