import Object from "../Object.js";
class Collectable extends Object {
    #animStep = 0;
    #animTimer = 0;
    #song = null;
    #isAlive;

    constructor(x, y, width, height, texturepath,spriteSheetOffsetX) {
        super(x, y, width, height, texturepath,spriteSheetOffsetX,0,width,height);
        this.#isAlive = true;
    }

    get animStep() {
        return this.#animStep;
    }

    set animStep(value) {
        this.#animStep = value;
    }

    get animTimer() {
        return this.#animTimer;
    }

    set animTimer(value) {
        this.#animTimer = value;
    }

    get song() {
        return this.#song;
    }

    set song(value) {
        this.#song = value;
    }

    get isAlive() {
        return this.#isAlive;
    }

    set isAlive(value) {
        this.#isAlive = value;
    }

    collide(player) {
       
        if(this.isAlive === false){
            return;
        }
        if(player.x >= this.x
            && player.x - player.width < this.x + this.width
            && player.y > this.y
            && player.y - player.height <= this.y + this.height){
              
            this.isRendered = false; 
            this.isAlive = false;

            if(this.song != null){
                this.playSound ? this.song.play() : null;
            }    
            this.collect(player);
        }
    }

    collect(player) {
    }

    render(ctx) {
        if(this.isRendered === false){
            return;
        }

        if(this.isAnimated === true){
            this.animTimer++;
            if(this.animTimer===8){
                this.animTimer = 0;
                this.animStep++;
                if(this.animStep === 4){
                    this.animStep = 0;
                }
            }
        }
        if(this.debug){
            ctx.fillStyle = 'rgba(230,230,230,0.75)';
            ctx.fillRect(this.x, this.y, this.width, this.height);

            ctx.fillStyle = 'rgba(0,0,0,1)';
            ctx.fillRect(this.x, this.y, 4, 4);
        }
        
        if(this.textureLoaded === true){
            ctx.drawImage(
                this.texture,
                this.spriteSheetOffsetX*this.width,
                this.width*this.animStep,
                this.width,
                this.height,
                this.x,
                this.y,
                this.width,
                this.height
            );
        }else{
            this.debug = true;
        }
    }
}

export default Collectable;